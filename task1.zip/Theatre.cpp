#include "Theatre.h"

std::vector<Perfomance> Theatre::getPerfomances() const
{
    return perfomances;
}

std::string Theatre::getName() const
{
    return name;
}

void Theatre::addPerfomance(const Perfomance perfomance)
{
    perfomances.push_back(perfomance);
}

void Theatre::setPerfomances(const std::vector<Perfomance> perfomances)
{
    this->perfomances = perfomances;
}

void Theatre::setName(const std::string name)
{
    this->name = name;
}

std::string Theatre::show() const
{
    std::string result = "";

    for (int i = 0; i < perfomances.size(); i++)
    {
        result += perfomances[i].show() + '\n';
    }

    return result;
}

