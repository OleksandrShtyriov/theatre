#include "Configurations.h"

int main()
{
    menu.run();
    
    return 0;
}

