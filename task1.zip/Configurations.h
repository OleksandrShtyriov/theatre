#ifndef CONFIGURATIONS_H_
#define CONFIGURATIONS_H_

#include <iostream>
#include <vector>

#include "Menu.h"
#include "Actor.h"
#include "Perfomance.h"
#include "Theatre.h"
#include "GetActors.h"
#include "ActorsVector.h"

//Theater name:
const std::string theatreName = "Cpp";

//Actor filenames:
const std::vector<std::string> filenames1{"Samuel.txt", "Roger.txt", "John.txt"};
const std::vector<std::string> filenames2{"Russell.txt"};
const std::vector<std::string> filenames3{"Bogdan.txt"};

//Actor vectors:
ActorsVector actors1 = ActorsVector(filenames1);
ActorsVector actors2 = ActorsVector(filenames2);
ActorsVector actors3 = ActorsVector(filenames3);

//Perfomances:
Perfomance perfomance1 = Perfomance(actors1.getVector(), "Perfomance1");
Perfomance perfomance2 = Perfomance(actors2.getVector(), "Perfomance2");
Perfomance perfomance3 = Perfomance(actors3.getVector(), "Perfomance3");

//perfomances initialization:
std::vector<Perfomance> perfomances{perfomance1, perfomance2, perfomance3};

//Theatre:
Theatre theatre = Theatre(perfomances, theatreName);

//Menu:
Menu menu = Menu(theatre);

#endif

